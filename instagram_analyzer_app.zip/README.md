# Instagram Analyzer

A Streamlit app that analyzes Instagram post engagement using the Graph API and logs insights to Google Sheets.

## Features
- Analyzes most engaging content type
- Suggests hashtags
- Logs data to Google Sheets
- Allows CSV export
